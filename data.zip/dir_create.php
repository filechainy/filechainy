<?php

if(!file_exists("user")){mkdir("user");}
if(!file_exists("urls")){mkdir("urls");}
if(!file_exists("url")){mkdir("url");}
if(!file_exists("tests")){mkdir("tests");}
if(!file_exists("team")){mkdir("team");}
if(!file_exists("paste")){mkdir("paste");}
if(!file_exists("logos")){mkdir("logos");}
if(!file_exists("keys")){mkdir("keys");}
if(!file_exists("Java")){mkdir("Java");}
if(!file_exists("img")){mkdir("img");}
if(!file_exists("hash_test")){mkdir("hash_test");}
if(!file_exists("hash")){mkdir("hash");}
if(!file_exists("groups")){mkdir("groups");}
if(!file_exists("files_urls")){mkdir("files_urls");}
if(!file_exists("files")){mkdir("files");}
if(!file_exists("fatcow")){mkdir("fatcow");}
if(!file_exists("comments")){mkdir("comments");}
if(!file_exists("categories")){mkdir("categories");}
if(!file_exists("background-image")){mkdir("background-image");}

if(!file_exists("background-image/simple")){
    mkdir("background-image/simple");
}

if(!file_exists("categories/uploaded")){
    mkdir("categories/uploaded");
}

if(!file_exists("categories/default")){
    mkdir("categories/default");
}


?>
