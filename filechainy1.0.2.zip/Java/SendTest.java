import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Base64;
import java.net.URL;
import java.net.HttpURLConnection;
import java.io.OutputStream;

public class SendTest {
    public static void main(String[] args) {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new FileReader("test.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
        } catch (IOException e) {
            System.err.println("An error occurred while reading the file: " + e.getMessage());
        }

        String fileContent = sb.toString();
        String encodedFile = Base64.getEncoder().encodeToString(fileContent.getBytes());

        try {
            URL url = new URL("http://localhost/filechainy/receive.php?contents=" + encodedFile);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.setDoOutput(true);

            try (OutputStream os = con.getOutputStream()) {
                os.write(encodedFile.getBytes());
            }

            int responseCode = con.getResponseCode();
            System.out.println("HTTP GET request sent to " + url + ", response code: " + responseCode);
        } catch (IOException e) {
            System.err.println("An error occurred while sending the GET request: " + e.getMessage());
        }
    }
}
