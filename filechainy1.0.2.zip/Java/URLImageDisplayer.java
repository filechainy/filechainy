import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import javax.swing.*;

public class URLImageDisplayer extends JFrame {
    private JTextField textField;
    private JPanel imagePanel;

    public URLImageDisplayer() {
        setTitle("URL Image Displayer");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        textField = new JTextField();
        JButton displayButton = new JButton("Display");
        displayButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                displayImages();
            }
        });

        JPanel inputPanel = new JPanel(new BorderLayout());
        inputPanel.add(textField, BorderLayout.CENTER);
        inputPanel.add(displayButton, BorderLayout.EAST);
        add(inputPanel, BorderLayout.NORTH);

        imagePanel = new JPanel(new GridLayout(0, 1));
        JScrollPane scrollPane = new JScrollPane(imagePanel);
        add(scrollPane, BorderLayout.CENTER);

        setVisible(true);
    }

    private void displayImages() {
        imagePanel.removeAll();
        String input = textField.getText();

        try {
            File file = new File(input);
            if (file.exists()) {
                BufferedReader reader = new BufferedReader(new FileReader(file));
                String line;
                while ((line = reader.readLine()) != null) {
                    displayImage(line);
                }
                reader.close();
            } else {
                URL url = new URL(input);
                BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()));
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] urls = line.split("\\s+");
                    for (String urlStr : urls) {
                        displayImage(urlStr);
                    }
                }
                reader.close();
            }
        } catch (Exception ex) {
            //JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        imagePanel.revalidate();
        imagePanel.repaint();
    }

    private void displayImage(String urlStr) {
        try {
            URL url = new URL(urlStr);
            Image image = Toolkit.getDefaultToolkit().createImage(url);
            ImageIcon icon = new ImageIcon(image);
            JLabel label = new JLabel(icon);
            label.setVerticalAlignment(JLabel.CENTER);
            imagePanel.add(label);
        } catch (Exception ex) {
            //JOptionPane.showMessageDialog(this, "Invalid URL: " + urlStr, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        new URLImageDisplayer();
    }
}
