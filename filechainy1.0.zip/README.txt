Filechainy 1.0 By filechainy

Software free to personal use.
For commercial use or make modifications purchase a license (15,00 USD)

https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=aerae4%40gmail%2ecom&lc=US&item_name=Registration%20fee&item_number=2&amount=15%2e00&currency_code=USD&button_subtype=services&no_note=0&bn=PP%2dBuyNowBF%3abtn_buynowCC_LG%2egif%3aNonHostedGuest

----------------------------------------------------------------------------------

Software gratuito para uso pessoal.
Para uso comercial ou fazer modifica��es compre uma licen�a (75,00 R$)

https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=aerae4%40gmail%2ecom&lc=BR&item_name=Taxa%20de%20inscri%c3%a7%c3%a3o&item_number=1&amount=75%2e00&currency_code=BRL&button_subtype=services&no_note=0&bn=PP%2dBuyNowBF%3abtn_paynow_SM%2egif%3aNonHostedGuest


Chave Pix: filechainy@gmail.com


All rights reserved/ Todos os direitos reservados
